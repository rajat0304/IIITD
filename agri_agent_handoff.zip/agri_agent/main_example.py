"""Minimal FastAPI wiring. Merge the route into the real app.
Run: GEMINI_API_KEY=your_key uvicorn main_example:app --reload"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from agent import ask

app = FastAPI(title="AgriSight API")


class Q(BaseModel):
    question: str


@app.post("/agent/ask")
def agent_ask(q: Q):  # plain def: FastAPI runs it in a thread pool (calls are blocking)
    try:
        return {"answer": ask(q.question)}
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
