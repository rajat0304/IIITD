"""AgriSight agent: Gemini + 2 tools (live weather, yield model).
Needs env var GEMINI_API_KEY and yield_model.pkl next to this file
(or set YIELD_MODEL_PATH)."""
import os, pickle, requests
import numpy as np
import pandas as pd
from google import genai
from google.genai import types

HERE = os.path.dirname(os.path.abspath(__file__))
_model = None
_client = None


def _yield_model():
    global _model
    if _model is None:
        path = os.environ.get("YIELD_MODEL_PATH", os.path.join(HERE, "yield_model.pkl"))
        with open(path, "rb") as f:
            _model = pickle.load(f)
    return _model


def _gemini():
    global _client
    if _client is None:
        _client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
    return _client


def get_weather(latitude: float, longitude: float) -> dict:
    """5-day weather forecast and count of blight-favourable (cool, humid) days for a location."""
    u = ("https://api.open-meteo.com/v1/forecast"
         f"?latitude={latitude}&longitude={longitude}"
         "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum"
         "&hourly=relative_humidity_2m&forecast_days=5&timezone=auto")
    d = requests.get(u, timeout=20).json()
    rh = np.array(d["hourly"]["relative_humidity_2m"], dtype=float)
    days = []
    for i, day in enumerate(d["daily"]["time"]):
        tmin = d["daily"]["temperature_2m_min"][i]
        tmax = d["daily"]["temperature_2m_max"][i]
        hum = float(rh[i * 24:(i + 1) * 24].mean())
        days.append({"date": day, "tmin": tmin, "tmax": tmax,
                     "rain_mm": d["daily"]["precipitation_sum"][i],
                     "humidity_pct": round(hum),
                     "blight_favourable": bool(tmin >= 10 and tmax <= 24 and hum >= 85)})
    return {"forecast": days,
            "blight_favourable_days": sum(x["blight_favourable"] for x in days),
            "note": "Simple rule of thumb (cool and humid days), not a validated model."}


def predict_yield(crop: str, season: str, state: str, year: int, area: float,
                  rainfall_mm: float, fertilizer_kg_per_ha: float,
                  pesticide_kg_per_ha: float) -> dict:
    """Estimate crop yield in tonnes per hectare. Season is Kharif, Rabi or Whole Year. Area in hectares."""
    row = pd.DataFrame([{"Crop": crop, "Season": season, "State": state,
                         "Crop_Year": int(year), "Area": area,
                         "Annual_Rainfall": rainfall_mm,
                         "Fertilizer": fertilizer_kg_per_ha * area,
                         "Pesticide": pesticide_kg_per_ha * area}])
    return {"yield_tonnes_per_hectare": round(float(_yield_model().predict(row)[0]), 2),
            "note": "Regional estimate from state-level data, not this exact field."}


SYSTEM = """You are AgriSight, an assistant for Indian farmers.
Reply in the user's language (Hindi, Hinglish or English), in short simple sentences.
For weather or disease-risk questions call get_weather with approximate coordinates of the place.
For yield questions call predict_yield; ask for any missing input first.
Never give pesticide or fungicide doses or product names. Say to check with the local KVK
or Kisan Call Centre (1800-180-1551).
Always mention uncertainty briefly. If a tool says rule of thumb or regional estimate, say so."""

MODELS = ["gemini-3.5-flash", "gemini-2.5-flash"]  # second is the fallback


def ask(question: str) -> str:
    cfg = types.GenerateContentConfig(system_instruction=SYSTEM,
                                      tools=[get_weather, predict_yield])
    last = None
    for name in MODELS:
        try:
            return _gemini().models.generate_content(
                model=name, contents=question, config=cfg).text
        except Exception as e:  # try the fallback model
            last = e
    raise RuntimeError(f"Gemini call failed: {last}")
