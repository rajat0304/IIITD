# AgriSight agent: handoff notes

## Files
- `agent.py`: `ask(question) -> str`. Gemini agent with 2 tools (live Open-Meteo weather, yield model).
- `main_example.py`: example FastAPI route `POST /agent/ask` with body `{"question": "..."}`.
- `yield_model.pkl`: XGBoost pipeline (must sit next to `agent.py`, or set `YIELD_MODEL_PATH`).
- `supported_values.json`: valid Crop / State / Season spellings for the yield model.
- `requirements.txt`: pin pandas, scikit-learn, xgboost to the Colab versions, or the pickle may not load.

## Setup
1. `pip install -r requirements.txt`
2. Get your OWN free key at aistudio.google.com, then `export GEMINI_API_KEY=...` (never commit it).
3. `uvicorn main_example:app --reload`, then open `/docs`.

## Notes
- The Gemini free tier has rate limits; add basic retry and caching if the demo gets busy.
- `ask()` is blocking, so use a plain `def` route (or `run_in_threadpool`).
- Yield model input: Crop, Season, State, Crop_Year, Area, Annual_Rainfall, Fertilizer, Pesticide
  (fertilizer/pesticide are totals in kg; the agent converts from kg/ha). Coconut is not supported.
  Unknown spellings do not raise an error; they just lose that feature's effect, so validate against `supported_values.json`.
- Blight signal is a simple rule of thumb (cool and humid days), not a validated model.
- The agent refuses to give pesticide doses by design; keep that behaviour in the UI.
